import { Component, OnInit } from '@angular/core';
import { Employees } from './employees';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

    public user:Employees[];

  

    title:String="data binding";
  constructor( ) {
     this.user=[];

  }
  

  public username='';

  public ngOnInit(): void {
    this.initializeUserRecords();
 
  
  }
  public initializeUserRecords():void{
    this.user=[{
      employee_Id:1,
      first_name:'om',
      last_name:'gupta',
      salary:10000,
      dob:new Date(),
      email:'omgupta@gmail.com',
      action:false
    },
  {
    employee_Id:10,
    first_name:'rahul',
    last_name:'singh',
    salary:100000,
    dob:new Date(),
    email:'rahulsingh@gmail.com',
    action:false

  }]
  }
  onclick()
  {
    this.title="Assignement 1 is completed";
    
  }
  onclick1()
  {
    alert(this.username);
  }


}
